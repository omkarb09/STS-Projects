package com.lti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.model.Student;

@Service
public interface StudentService {
	public List<Student> findAllStudents();
	public Student findStudentById(int id);
	public Student addStudent(Student student);
	public Student updateStudent(Student student);
	public void deleteStudent(int id);
}
