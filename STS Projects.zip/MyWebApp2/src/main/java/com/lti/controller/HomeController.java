package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lti.model.Student;
import com.lti.repository.StudentRepo;

@Controller
public class HomeController 
{
	@Autowired
	StudentRepo repo;
	
	@RequestMapping("home")
	public String home()
	{
		return "Home";
	}
	
	@RequestMapping("addStudent")
	@ResponseBody
	public String addStudent(Student student)
	{
		repo.save(student);
		return "added";
	}
	
	@RequestMapping("viewStudent")
	@ResponseBody
	public List<Student> viewAllStudent()
	{
		return repo.findAll();
		
	}
	
}

/*server.port=9088
spring.datasource.url=jdbc:oracle:thin:@localhost:1521:xe
spring.datasource.username=hr
spring.datasource.password=hr*/