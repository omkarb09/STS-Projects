package com.lti.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.lti.model.Student;
import com.lti.repository.StudentRepo;

@Controller
public class HomeController 
{
	@Autowired
	StudentRepo repo;
	
	@RequestMapping("home")
	public String home()
	{
		return "Home";
	}
	
	@GetMapping(value="addStudentPage")
	public String addStudentPage()
	{
		return "Add";
	}
	
	@RequestMapping("addStudent")
	@ResponseBody
	public String addStudent(Student student)
	{
		repo.save(student);
		return "added";
	}
	
	@GetMapping(value="viewStudent")
	@ResponseBody
	public List<Student> viewAllStudent()
	{
		return repo.findAll();
		
	}
	
	
	
	@GetMapping(value="deleteStudentPage")
	public String deleteStudentPage()
	{
		return "Delete";
	}
	
	@PostMapping(value="deleteStudent")
	@ResponseBody
	public String deleteStudent(@RequestParam("id") String id)
	{
		repo.deleteById(Integer.parseInt(id));
		return "deleted";
	}
	
	@GetMapping(value="updateStudentPage")
	public String updateStudentPage()
	{
		return "Update";
	}
	
	@PostMapping(value="updateStudentForm")
	public ModelAndView updateStudentForm(@RequestParam("id") String id)
	{
		Student stud =repo.findById(Integer.parseInt(id)).orElse(null);
		ModelAndView mv = new ModelAndView("UpdateForm");
		mv.addObject("stud",stud);
		return mv;
	}
	
	@PostMapping(value="updateStudent")
	@ResponseBody
	public String updateStudent(Student stud)
	{
		repo.save(stud);
		return "updated";
	}
	
}

/*server.port=9088
spring.datasource.url=jdbc:oracle:thin:@localhost:1521:xe
spring.datasource.username=hr
spring.datasource.password=hr*/